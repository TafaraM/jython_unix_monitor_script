#######NODE1####################

perfStr = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

print #####################

print "############### Node 1 - Transaction Manager #############################"

###print perfStr

perfObj = AdminControl.makeObjectName(perfStr)


#####type(perfObj)

srvrStr = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

srvrObj = AdminControl.makeObjectName(srvrStr)

stats = AdminControl.invoke_jmx( perfObj, 'getStatsObject', [ srvrObj, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])



TMGlobalTCNode1 = stats.getStats('transactionModule').getStatistic('GlobalTimeoutCount').getCount()

TMLocalTCNode1 = stats.getStats('transactionModule').getStatistic('LocalTimeoutCount').getCount()



print 'M_A TMGfirstnode:%d' %(TMGlobalTCNode1)

print 'M_B TMLfirstnode:%d' %(TMLocalTCNode1)



#######NODE2####################

perfStr2 = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

print ###############################

print "############### Node 2 - Transaction Manager  #############################"

###print perfStr2

perfObj2 = AdminControl.makeObjectName(perfStr2)


#####type(perfObj)

srvrStr2 = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

srvrObj2 = AdminControl.makeObjectName(srvrStr2)

stats2 = AdminControl.invoke_jmx( perfObj2, 'getStatsObject', [ srvrObj2, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])


TMGlobalTCNode2 = stats2.getStats('transactionModule').getStatistic('GlobalTimeoutCount').getCount()

TMLocalTCNode2 = stats2.getStats('transactionModule').getStatistic('LocalTimeoutCount').getCount()



print 'M_C TMGsecondnode:%d' %(TMGlobalTCNode2)

print 'M_D TMLsecondnode:%d' %(TMLocalTCNode2)


