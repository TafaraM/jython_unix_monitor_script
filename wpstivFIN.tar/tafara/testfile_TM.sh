#!/usr/bin/ksh


###Variables
PROFILE_HOME=/opt/ibm/WebSphere/ProcServer/profiles/Custom01
JY1_LOG=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog.log
JY1_LOG_2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_bak1.log
JY1_LOG_TM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM.log
JY1_LOG_TM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM_bak1.log
JY1_LOG_JVM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM.log
JY1_LOG_JVM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM_bak1.log

echo $JY1_LOG_TM

N1tmglobvar_old=`grep -iR "TMGfirstnode*" testfilelog_TM_bak1.log | egrep "[0-9]{1,}" -o`
N1tmlocvar_old=`grep -iR "TMLfirstnode*" testfilelog_TM_bak1.log | egrep "[0-9]{1,}" -o`
N2tmglobvar_old=`grep -iR "TMGsecondnode*" testfilelog_TM_bak1.log | egrep "[0-9]{1,}" -o`
N2tmlocvar_old=`grep -iR "TMLsecondnode*" testfilelog_TM_bak1.log | egrep "[0-9]{1,}" -o`

N1tmglobvar=`grep -iR "TMGfirstnode*" testfilelog_TM.log | egrep "[0-9]{1,}" -o`
N1tmlocvar=`grep -iR "TMLfirstnode*" testfilelog_TM.log | egrep "[0-9]{1,}" -o`
N2tmglobvar=`grep -iR "TMGsecondnode*" testfilelog_TM.log | egrep "[0-9]{1,}" -o`
N2tmlocvar=`grep -iR "TMLsecondnode*" testfilelog_TM.log | egrep "[0-9]{1,}" -o`



echo $N1tmglobvar_old
echo $N1tmlocvar_old
echo $N2tmglobvar_old
echo $N2tmlocvar_old

echo $N1tmglobvar
echo $N1tmlocvar
echo $N2tmglobvar
echo $N2tmlocvar


if [ -z $N1tmglobvar_old ] || [ -z $N1tmlocvar_old ] || [ -z $N2tmglobvar_old ] || [ -z $N2tmlocvar_old ] || [ -z $N1tmglobvar ] || [ -z $N1tmlocvar ] || [ -z $N2tmglobvar ] || [ -z $N2tmlocvar ]
then
    echo "ALERT - current timeout values do not exist - storing them in properties file for the next check"
    exit 1;

else
    echo "TM values do exist - A comparison to the previous value will be done"
    continue
fi



#####

#### 4 if elses


if [ $N1tmglobvar -gt $N1tmglobvar_old ]
then
    echo "ALERT - New TM Value bigger than old "

######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/M_A/ALERT - Old N1 TMValue is:'$N1tmglobvar_old',\n and the New Value: /' testfilelog_TM.log

else
    echo "Values appear to be ok"
    continue
fi


if [ $N1tmlocvar -gt $N1tmlocvar_old ]
then
    echo "ALERT - New TM Value bigger than old "

######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/M_B/ALERT - Old N1 TMValue is:'$N1tmlocvar_old',\n and the New Value: /' testfilelog_TM.log

else
    echo "Values appear to be ok"
    continue
fi


if [ $N2tmglobvar -gt $N2tmglobvar_old ]
then
    echo "ALERT - New TM Value bigger than old "

#####do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/M_C/ALERT - Old N2 TMValue is:'$$N2tmglobvar_old',\n and the New Value: /' testfilelog_TM.log

else
    echo "Values appear to be ok"
    continue
fi


if [ $N2tmlocvar -gt $N2tmlocvar_old ]
then
    echo "ALERT - New TM Value bigger than old "

#######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/M_D/ALERT - Old N2 TMValue is:'$N2tmlocvar_old',\n and the New Value: /' testfilelog_TM.log

else
    echo "Values appear to be ok"
    continue
fi




