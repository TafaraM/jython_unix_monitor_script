#!/usr/bin/ksh

sed -i 's/wps_mailchkprop../wps_mailchkprop=0/g' wpstestmailenv.prop
