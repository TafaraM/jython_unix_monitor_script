#!/usr/bin/ksh


###Variables
PROFILE_HOME=/opt/ibm/WebSphere/ProcServer/profiles/Custom01
JY1_LOG=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog.log
JY1_LOG_2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_bak1.log
JY1_LOG_TM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM.log
JY1_LOG_TM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM_bak1.log
JY1_LOG_JVM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM.log
JY1_LOG_JVM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM_bak1.log
mailchkvar=`grep -iR "wps_mailchkprop*" wpstestmailenv.prop`
alertcheck1=`grep -ism 1 alert $JY1_LOG`
alertcheck2=`grep -ism 1 alert $JY1_LOG_TM`
alertcheck3=`grep -ism 1 alert $JY1_LOG_JVM`


###echo $SSH_CLIENT
###echo $LOGNAME
###echo $LANG

echo $mailchkvar


###### Execute scripts to create log files and rotate log to backup

$PROFILE_HOME/bin/testfile.sh

echo $JY1_LOG_TM
 
if [[ -f $JY1_LOG_TM ]]

then
   echo "$JY1_LOG_TM exists, one backup will be created"

        rm -r $JY1_LOG_TM2

        mv $JY1_LOG_TM $JY1_LOG_TM2

##### Just in case the move fails for some reason

        rm -r $JY1_LOG_TM

else
   echo "$JY1_LOG_TM does not exist, it will be created automatically."

###   exit 1;
fi

$PROFILE_HOME/bin/wsadmin.sh -lang jython -user admin -password admin -f  TMvalues.py >> testfilelog_TM.log

$PROFILE_HOME/bin/testfile_TM.sh


echo $JY1_LOG_JVM 

if [[ -f $JY1_LOG_JVM ]]

then
   echo "$JY1_LOG_JVM exists, one backup will be created"

        rm -r $JY1_LOG_JVM2

        mv $JY1_LOG_JVM $JY1_LOG_JVM2

##### Just in case the move fails for some reason

        rm -r $JY1_LOG_JVM

else
   echo "$JY1_LOG_JVM does not exist, it will be created automatically."

###   exit 1;
fi

$PROFILE_HOME/bin/wsadmin.sh -lang jython -user admin -password admin -f JVMvalues.py >> testfilelog_JVM.log

$PROFILE_HOME/bin/testfile_JVM.sh 



###### Check error condition in logs and send emails


############# ALERT CHECKING ##############################
alertcheck1=`grep -ism 1 alert $JY1_LOG`
alertcheck2=`grep -ism 1 alert $JY1_LOG_TM`
alertcheck3=`grep -ism 1 alert $JY1_LOG_JVM`


echo $alertcheck1
echo $alertcheck2
echo $alertcheck3


if [ -z $alertcheck1 ] && [ -z $alertcheck2 ] && [ -z $alertcheck3 ]
then
    echo "ALERT does not exist in the log files - EXIT"
    exit 1;

else
    echo "ALERT does exist here - CONTINUE"
    continue
fi



####cat testfilelog.log testfilelog_bak1.log | mail -s "WAS Tivoli Vars Test" TafaraMahlahla@odysseylogistics.com, tafara@gmail.com


####mail -s "WAS Tivoli Vars Test" TafaraMahlahla@odysseylogistics.com -c tafara@gmail.com -c ffront@usa.net < testfilelog.log

echo $mailchkvar


if [ "$mailchkvar" = "wps_mailchkprop=0" ]; then
	echo "WPS MAil var equals 0"
	sed -i 's/wps_mailchkprop=0/wps_mailchkprop=1/g' wpstestmailenv.prop
        
#### send mail


elif [ "$mailchkvar" = "wps_mailchkprop=1" ]; then
	echo "WPS MAil var equals 1"
	sed -i 's/wps_mailchkprop=1/wps_mailchkprop=2/g' wpstestmailenv.prop

#### send mail


elif [ "$mailchkvar" = "wps_mailchkprop=2" ]; then
	echo "WPS MAil var equals 2"
	sed -i 's/wps_mailchkprop=2/wps_mailchkprop=3/g' wpstestmailenv.prop

#### send mail


elif [ "$mailchkvar" = "wps_mailchkprop=3" ]; then
        echo "WPS MAIL var equals 3 - MAXIMUM NUMBER OF E-MAILS SENT FOR THIS TIMEFRAME"
        exit

else 
        echo "WPS MAil var equals UKNOWN VALUE - PLEASE CHECK THE PROPERTIES FILE FOR THE VALUE OF wps_mailchkprop"

fi



###cat testfilelog.log testfilelog_bak1.log | mail -s "WAS Tivoli Vars Test" TafaraMahlahla@odysseylogistics.com, SergeyTarasenko@odysseylogistics.com, alexeygatsenko@odysseylogistics.com, tafara@gmail.com


###cat testfilelog.log testfilelog_TM.log | mail -s "WAS Tivoli Vars Test" TafaraMahlahla@odysseylogistics.com, SergeyTarasenko@odysseylogistics.com, alexeygatsenko@odysseylogistics.com, tafara@gmail.com


cat testfilelog.log testfilelog_TM.log testfilelog_JVM.log | mail -s "WAS Tivoli Vars Test" TafaraMahlahla@odysseylogistics.com, alexeygatsenko@odysseylogistics.com,


