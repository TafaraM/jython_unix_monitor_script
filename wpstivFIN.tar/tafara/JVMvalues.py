#######NODE1####################

perfStr = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

print #####################

print "############### Node 1 - JVM #############################"

###print perfStr

perfObj = AdminControl.makeObjectName(perfStr)


#####type(perfObj)

srvrStr = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

srvrObj = AdminControl.makeObjectName(srvrStr)

stats = AdminControl.invoke_jmx( perfObj, 'getStatsObject', [ srvrObj, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])



CurJVMNode1 = stats.getStats('jvmRuntimeModule').getStatistic('HeapSize').getCurrent()

HWJVMNode1 = stats.getStats('jvmRuntimeModule').getStatistic('HeapSize').getHighWaterMark()

UBJVMNode1 = stats.getStats('jvmRuntimeModule').getStatistic('HeapSize').getUpperBound()

FreeJVMNode1 = stats.getStats('jvmRuntimeModule').getStatistic('FreeMemory').getCount()


print 'J_A JVMHeapFistNode:%d' %(CurJVMNode1)

print 'J_B JVMHighWaterFirstNode:%d' %(HWJVMNode1)

print 'J_C JVMUpperBoundFirstNode:%d' %(UBJVMNode1)

print 'J_D JVMFreeFristNode:%d' %(FreeJVMNode1)


#######NODE2####################

perfStr2 = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

print ###############################

print "############### Node 2 - JVM  #############################"

###print perfStr2

perfObj2 = AdminControl.makeObjectName(perfStr2)


#####type(perfObj)

srvrStr2 = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

srvrObj2 = AdminControl.makeObjectName(srvrStr2)

stats2 = AdminControl.invoke_jmx( perfObj2, 'getStatsObject', [ srvrObj2, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])


CurJVMNode2 = stats2.getStats('jvmRuntimeModule').getStatistic('HeapSize').getCurrent()

HWJVMNode2 = stats2.getStats('jvmRuntimeModule').getStatistic('HeapSize').getHighWaterMark()

UBJVMNode2 = stats2.getStats('jvmRuntimeModule').getStatistic('HeapSize').getUpperBound()

FreeJVMNode2 = stats2.getStats('jvmRuntimeModule').getStatistic('FreeMemory').getCount()


print 'J_E JVMHeapSecNode:%d' %(CurJVMNode2)

print 'J_F JVMHighWaterSecNode:%d' %(HWJVMNode2)

print 'J_G JVMUpperBoundSecNode:%d' %(UBJVMNode2)

print 'J_H JVMFreeSecNode:%d' %(FreeJVMNode2)

