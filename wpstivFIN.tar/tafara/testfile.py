
###pyunixvar = 

###os.system("printenv PYCHECK")

###print AdminControl.queryNames('type=Perf,*')

#######NODE1####################

perfStr = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

print #####################

print "############### Node 1 #############################"

print perfStr

perfObj = AdminControl.makeObjectName(perfStr)


#####type(perfObj)

srvrStr = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung1Node01.0,node=plung1Node01,*')

srvrObj = AdminControl.makeObjectName(srvrStr)

stats = AdminControl.invoke_jmx( perfObj, 'getStatsObject', [ srvrObj, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])


################################### JDBC HEALTH CHECKS #############################################################################################


jdbc1 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('WaitingThreadCount').getCurrent()

if jdbc1 != 0L:

	print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent WaitingThreadCount:%d' %(jdbc1)
else: 

	print 'OK - jdbc/OLTEvent WaitingThreadCount is:%d' %(jdbc1)



jdbc2 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('FaultCount').getCount()

if jdbc2 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent FaultCount:%d' %(jdbc2)
else:

        print 'OK - jdbc/OLTEvent FaultCount is:%d' %(jdbc2)


jdbc3 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('WaitTime').getCount()

if jdbc3 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent WaitTime:%d' %(jdbc3)
else:

        print 'OK - jdbc/OLTEvent WaitTime is:%d' %(jdbc3)


jdbc4 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('WaitingThreadCount').getCurrent()

if jdbc4 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning WaitingThreadCount:%d' %(jdbc4)
else:

        print 'OK - jdbc/Planning WaitingThreadCount is:%d' %(jdbc4)


jdbc5 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('FaultCount').getCount()

if jdbc5 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning FaultCount:%d' %(jdbc5)
else:

        print 'OK - jdbc/Planning FaultCount is:%d' %(jdbc5)


jdbc6 = stats.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('WaitTime').getCount()

if jdbc6 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning WaitTime:%d' %(jdbc6)
else:

        print 'OK - jdbc/Planning WaitTime is:%d' %(jdbc6)


################################ END JDBC HEALTH CHECKS #######################################################################################


################################ JCA HEALTH CHECKS #########################################################################################


jca1 = stats.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$BookingResponseInEndPoint').getStatistic('WaitingThreadCount').getCurrent()

if jca1 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$BookingResponseInEndPoint WaitingThreadCount:%d' %(jca1)
else:

        print 'OK - JMS$BookingResponseInEndPoint WaitingThreadCount is:%d' %(jca1)



jca2 = stats.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$BookingResponseInEndPoint').getStatistic('WaitTime').getCount()

if jca2 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$BookingResponseInEndPoint WaitTime:%d' %(jca2)
else:

        print 'OK - JMS$BookingResponseInEndPoint WaitTime is:%d' %(jca2)


jca3 = stats.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$ShipmentOutCF').getStatistic('WaitingThreadCount').getCurrent()

if jca3 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$ShipmentOutCF WaitingThreadCount:%d' %(jca3)
else:

        print 'OK - JMS$ShipmentOutCF WaitingThreadCount is:%d' %(jca3)



jca4 = stats.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$ShipmentOutCF').getStatistic('WaitTime').getCount()

if jca4 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$ShipmentOutCF WaitTime:%d' %(jca4)
else:

        print 'OK - JMS$ShipmentOutCF WaitTime is:%d' %(jca4)


################################ END JCA HEALTH CHECKS #########################################################################################


############################# WEBAPPLICATIONS ERROR COUNT HEALTH CHECKS #########################################################################################



err1 = stats.getStats('webAppModule').getStatistic('ErrorCount').getCount()

if err1 != 0L:

        print 'ALERT - UNEXPECTED VALUE for webAppModule ErrorCount:%d' %(err1)
else:

        print 'OK - webAppModule ErrorCount is:%d' %(err1)


############################# END WEBAPPLICATIONS ERROR COUNT HEALTH CHECKS ###################################################################################


#######NODE2####################

perfStr2 = AdminControl.queryNames('type=Perf,process=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

print ###############################

print "############### Node 2 #############################"

print perfStr2

perfObj2 = AdminControl.makeObjectName(perfStr2)


#####type(perfObj)

srvrStr2 = AdminControl.queryNames('type=Server,name=plung.AppTarget.plung2Node01.0,node=plung2Node01,*')

srvrObj2 = AdminControl.makeObjectName(srvrStr2)

stats2 = AdminControl.invoke_jmx( perfObj2, 'getStatsObject', [ srvrObj2, java.lang.Boolean('true')],['javax.management.ObjectName', 'java.lang.Boolean'])


################################### JDBC HEALTH CHECKS #############################################################################################


jdbc1 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('WaitingThreadCount').getCurrent()

if jdbc1 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent WaitingThreadCount:%d' %(jdbc1)
else:

        print 'OK - jdbc/OLTEvent WaitingThreadCount is:%d' %(jdbc1)


jdbc2 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('FaultCount').getCount()

if jdbc2 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent FaultCount:%d' %(jdbc2)
else:

        print 'OK - jdbc/OLTEvent FaultCount is:%d' %(jdbc2)


jdbc3 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/OLTEvent').getStatistic('WaitTime').getCount()

if jdbc3 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/OLTEvent WaitTime:%d' %(jdbc3)
else:

        print 'OK - jdbc/OLTEvent WaitTime is:%d' %(jdbc3)


jdbc4 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('WaitingThreadCount').getCurrent()

if jdbc4 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning WaitingThreadCount:%d' %(jdbc4)
else:

        print 'OK - jdbc/Planning WaitingThreadCount is:%d' %(jdbc4)


jdbc5 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('FaultCount').getCount()

if jdbc5 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning FaultCount:%d' %(jdbc5)
else:

        print 'OK - jdbc/Planning FaultCount is:%d' %(jdbc5)


jdbc6 = stats2.getStats('connectionPoolModule').getStats('Oracle JDBC Driver (XA)').getStats('jdbc/Planning').getStatistic('WaitTime').getCount()

if jdbc6 != 0L:

        print 'ALERT - UNEXPECTED VALUE for jdbc/Planning WaitTime:%d' %(jdbc6)
else:

        print 'OK - jdbc/Planning WaitTime is:%d' %(jdbc6)


################################ END JDBC HEALTH CHECKS #######################################################################################


################################ JCA HEALTH CHECKS #########################################################################################


jca1 = stats2.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$BookingResponseInEndPoint').getStatistic('WaitingThreadCount').getCurrent()

if jca1 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$BookingResponseInEndPoint WaitingThreadCount:%d' %(jca1)
else:

        print 'OK - JMS$BookingResponseInEndPoint WaitingThreadCount is:%d' %(jca1)



jca2 = stats2.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$BookingResponseInEndPoint').getStatistic('WaitTime').getCount()

if jca2 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$BookingResponseInEndPoint WaitTime:%d' %(jca2)
else:

        print 'OK - JMS$BookingResponseInEndPoint WaitTime is:%d' %(jca2)


jca3 = stats2.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$ShipmentOutCF').getStatistic('WaitingThreadCount').getCurrent()

if jca3 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$ShipmentOutCF WaitingThreadCount:%d' %(jca3)
else:

        print 'OK - JMS$ShipmentOutCF WaitingThreadCount is:%d' %(jca3)



jca4 = stats2.getStats('j2cModule').getStats('jmsConnections').getStats('JMS$ShipmentOutCF').getStatistic('WaitTime').getCount()

if jca4 != 0L:

        print 'ALERT - UNEXPECTED VALUE for JMS$ShipmentOutCF WaitTime:%d' %(jca4)
else:

        print 'OK - JMS$ShipmentOutCF WaitTime is:%d' %(jca4)


################################ END JCA HEALTH CHECKS #########################################################################################


############################# WEBAPPLICATIONS ERROR COUNT HEALTH CHECKS#########################################################################################



err1 = stats2.getStats('webAppModule').getStatistic('ErrorCount').getCount()

if err1 != 0L:

        print 'ALERT - UNEXPECTED VALUE for webAppModule ErrorCount:%d' %(err1)
else:

        print 'OK - webAppModule ErrorCount is:%d' %(err1)


############################# END WEBAPPLICATIONS ERROR COUNT HEALTH CHECKS###################################################################################
