#!/usr/bin/ksh


###Variables
PROFILE_HOME=/opt/ibm/WebSphere/ProcServer/profiles/Custom01
JY1_LOG=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog.log
JY1_LOG_2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_bak1.log



echo $JY1_LOG 

if [[ -f $JY1_LOG ]]

then
   echo "$JY1_LOG exists, one backup will be created"

        rm -r $JY1_LOG_2

        mv $JY1_LOG $JY1_LOG_2

##### Just in case the move fails for some reason

        rm -r $JY1_LOG

else
   echo "$JY1_LOG does not exist, it will be created automatically."

   continue;
fi

$PROFILE_HOME/bin/wsadmin.sh -lang jython -user admin -password admin -f  testfile.py >> testfilelog.log





