#!/usr/bin/ksh


###Variables
PROFILE_HOME=/opt/ibm/WebSphere/ProcServer/profiles/Custom01
JY1_LOG=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog.log
JY1_LOG_2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_bak1.log
JY1_LOG_TM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM.log
JY1_LOG_TM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_TM_bak1.log
JY1_LOG_JVM=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM.log
JY1_LOG_JVM2=/opt/ibm/WebSphere/ProcServer/profiles/Custom01/bin/testfilelog_JVM_bak1.log

echo $JY1_LOG_JVM

N1jvmheap_old=`grep -iR "JVMHeapFistNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N1jvmhighwater_old=`grep -iR "JVMHighWaterFirstNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N1jvmupperbound_old=`grep -iR "JVMUpperBoundFirstNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N1jvmfree_old=`grep -iR "JVMFreeFristNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N2jvmheap_old=`grep -iR "JVMHeapSecNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N2jvmhighwater_old=`grep -iR "JVMHighWaterSecNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N2jvmupperbound_old=`grep -iR "JVMUpperBoundSecNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`
N2jvmfree_old=`grep -iR "JVMFreeSecNode*" testfilelog_JVM_bak1.log | egrep "[0-9]{1,}" -o`


N1jvmheap=`grep -iR "JVMHeapFistNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N1jvmhighwater=`grep -iR "JVMHighWaterFirstNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N1jvmupperbound=`grep -iR "JVMUpperBoundFirstNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N1jvmfree=`grep -iR "JVMFreeFristNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N2jvmheap=`grep -iR "JVMHeapSecNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N2jvmhighwater=`grep -iR "JVMHighWaterSecNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N2jvmupperbound=`grep -iR "JVMUpperBoundSecNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`
N2jvmfree=`grep -iR "JVMFreeSecNode*" testfilelog_JVM.log | egrep "[0-9]{1,}" -o`

Freememcheck=1000000
FreememMinVal=400000


echo $Freememcheck
echo $FreememMinVal


echo $N1jvmheap_old
echo $N1jvmhighwater_old
echo $N1jvmupperbound_old
echo $N1jvmfree_old
echo $N2jvmheap_old
echo $N2jvmhighwater_old
echo $N2jvmupperbound_old
echo $N2jvmfree_old

echo "#################################"


echo $N1jvmheap
echo $N1jvmhighwater
echo $N1jvmupperbound
echo $N1jvmfree
echo $N2jvmheap
echo $N2jvmhighwater
echo $N2jvmupperbound
echo $N2jvmfree




if [ -z $N1jvmheap_old ] || [ -z $N1jvmhighwater_old ] || [ -z $N1jvmupperbound_old ] || [ -z $N1jvmfree_old ] || [ -z $N2jvmheap_old ] || [ -z $N2jvmhighwater_old ] || [ -z $N2jvmupperbound_old ] || [ -z $N2jvmfree_old ] || [ -z $N1jvmheap ] || [ -z $N1jvmhighwater ] || [ -z $N1jvmupperbound ] || [ -z $N1jvmfree ] || [ -z $N2jvmheap ] || [ -z $N2jvmhighwater ] || [ -z $N2jvmupperbound ] || [ -z $N2jvmfree ]
then
    echo "ALERT - current jvm values do not exist - storing them in properties file for the next check"
    exit 1;

else
    echo "JVM values do exist - A comparison to the previous values will be done"
    continue
fi



##### Checking heap useage


if [ $N1jvmheap -ge $N1jvmupperbound ] || [ $N2jvmheap -ge $N2jvmupperbound ]
then
    echo "ALERT - Full JVM in use, checking free memory conditions "

else
    echo "Max JVM not in use"
    exit 1;
fi

#################### Free memory of 1GB ###################################################

if [ $N1jvmfree -lt $Freememcheck ]
then
    echo "ALERT - Free Memory less than 1GB while max heap in use "

######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/J_D/ALERT - Free Memory less than 1GB while max heap in use. Current FreeMem is: /' testfilelog_JVM.log

else
    echo "Free Memory is more than 1GB"
    continue
fi


if [ $N2jvmfree -lt $Freememcheck ]
then
    echo "ALERT - Free Memory less than 1GB while max heap in use "

######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/J_H/ALERT - Free Memory less than 1GB while max heap in use. Current FreeMem is: /' testfilelog_JVM.log

else
    echo "Free Memory is more than 1GB"
    continue
fi


########################### Checking if GC occurred #######################

if [ $N1jvmfree -gt $N1jvmfree_old ] || [ $N2jvmfree -gt $N2jvmfree_old ]
then
    echo "ALERT - Garbage collection has occurred since last memory check "
    continue

else
    echo "GC has probably not occurred yet"
    exit 1;
fi

####################### Checking if minimum garbage collection levels breached ###########


if [ $N1jvmfree -lt $FreememMinVal ]
then
    echo "ALERT - GC may not have freed up enough memory "

#######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/J_D/ALERT - GC may not have freed up enough memory. Current Free Mem is: /' testfilelog_JVM.log

else
    echo "Sufficient memory freed during last GC"
    continue
fi



if [ $N2jvmfree -lt $FreememMinVal ]
then
    echo "ALERT - GC may not have freed up enough memory "

#######do some sed stuff ######################################## sed in an Alert and the old and new variable values

sed -i 's/J_H/ALERT - GC may not have freed up enough memory. Current Free Mem is: /' testfilelog_JVM.log

else
    echo "Sufficient memory freed during last GC"
    continue
fi


